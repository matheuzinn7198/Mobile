package com.example.tela_inicial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
